/**
 * ABC Terroirs : raccourcis de navigation et appels à l'action (CTA)
 * Chargé par le module abcdesign. Pour tout retirer : désactiver le module.
 * Les liens se modifient dans les listes LIENS_RAPIDES, BUDGETS et CTA ci-dessous.
 */
(function () {
  'use strict';

  var BASE = 'https://abcterroirs.com/';
  var TEL = '02 40 89 76 26';

  // Raccourcis affichés sous le menu, sur toutes les pages
  var LIENS_RAPIDES = [
    ['🎄 Noël', '172-idees-cadeaux-noel'],
    ['Coffrets cadeaux', '3-coffrets-gourmands'],
    ['Moins de 25 €', '30-selection-moins-de-25'],
    ['Vins', '5-vins'],
    ['Whiskies', '12-whiskies'],
    ['Bières locales', '7-bieres'],
    ['Épicerie fine', '4-epicerie'],
    ['Sans alcool', '167-sans-alcool'],
    ['Cadeaux d\'entreprise', '163-infos-pour-les-pros']
  ];

  // Blocs « Un coffret pour chaque budget » de l'accueil
  var BUDGETS = [
    ['Moins de 25 €', 'Petites attentions', '30-selection-moins-de-25'],
    ['25 à 50 €', 'Les incontournables', '31-selection-25-a-50'],
    ['Plus de 50 €', 'Pour faire sensation', '32-selection-plus-de-50'],
    ['Sur mesure', 'Vous choisissez, on compose', 'nous-contacter']
  ];

  function el(tag, cls, html) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (html) e.innerHTML = html;
    return e;
  }
  function esc(s) { return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;'); }

  function ready(fn) {
    if (document.readyState !== 'loading') fn(); else document.addEventListener('DOMContentLoaded', fn);
  }

  ready(function () {
    var body = document.body;
    var page = body.id || '';
    if (page === 'checkout' || page === 'order-confirmation') return; // tunnel de commande : rien à ajouter

    // 1. Barre de recherche : un exemple concret de ce qu'on peut chercher
    var s = document.querySelector('#search_widget input[name="s"]');
    if (s) {
      s.setAttribute('placeholder', 'Coffret, muscadet, whisky, petit beurre…');
      s.setAttribute('aria-label', 'Rechercher un produit');
    }

    // 2. Raccourcis sous le menu
    var header = document.getElementById('header');
    if (header && !document.querySelector('.abc-quick')) {
      var bar = el('nav', 'abc-quick');
      bar.setAttribute('aria-label', 'Accès rapide');
      var inner = el('div', 'abc-quick__inner');
      LIENS_RAPIDES.forEach(function (l) {
        var a = el('a', 'abc-chip' + (l[1].indexOf('noel') > -1 ? ' abc-chip--hot' : ''), esc(l[0]));
        a.href = BASE + l[1];
        if (location.href.indexOf(l[1]) > -1) a.className += ' is-active';
        inner.appendChild(a);
      });
      bar.appendChild(inner);
      var menuBar = header.querySelector('.header-top-inner');
      if (menuBar && window.innerWidth >= 992) menuBar.parentNode.insertBefore(bar, menuBar);   // ordinateur : entre logo et menu
      else header.parentNode.insertBefore(bar, header.nextSibling);                              // mobile : sous l'en-tête
    }

    // 3. Accueil : boutons sous le texte de présentation + blocs par budget
    if (page === 'index') {
      var intro = document.querySelector('#czbannercmsblock .container');
      if (intro && !intro.querySelector('.abc-cta-row')) {
        var row = el('div', 'abc-cta-row',
          '<a class="abc-btn abc-btn--main" href="' + BASE + '3-coffrets-gourmands">Voir tous les coffrets</a>' +
          '<a class="abc-btn abc-btn--ghost" href="' + BASE + '172-idees-cadeaux-noel">Idées cadeaux de Noël</a>' +
          '<a class="abc-btn abc-btn--ghost" href="' + BASE + 'nous-contacter">Composer un coffret sur mesure</a>');
        intro.appendChild(row);

        var budgets = el('section', 'abc-budgets');
        budgets.appendChild(el('h2', 'abc-budgets__title', 'Un coffret pour chaque budget'));
        var grid = el('div', 'abc-budgets__grid');
        BUDGETS.forEach(function (b, i) {
          var a = el('a', 'abc-budget' + (i === BUDGETS.length - 1 ? ' abc-budget--custom' : ''),
            '<strong>' + esc(b[0]) + '</strong><span>' + esc(b[1]) + ' →</span>');
          a.href = BASE + b[2];
          grid.appendChild(a);
        });
        budgets.appendChild(grid);
        var block = document.getElementById('czbannercmsblock');
        block.parentNode.insertBefore(budgets, block.nextSibling);
      }
    }

    // 4. Avant le pied de page : bandeau « sur mesure / entreprises » (sauf panier)
    var footer = document.getElementById('footer');
    if (footer && page !== 'cart' && !document.querySelector('.abc-cta-band')) {
      var band = el('section', 'abc-cta-band',
        '<div class="abc-cta-band__inner">' +
          '<div class="abc-cta-band__text">' +
            '<h2>Un coffret sur mesure, pour offrir ou pour votre entreprise ?</h2>' +
            '<p>Dites-nous votre budget et vos envies : nous le composons à la main, place Saint-Pierre à Nantes.</p>' +
          '</div>' +
          '<div class="abc-cta-band__actions">' +
            '<a class="abc-btn abc-btn--light" href="' + BASE + 'nous-contacter">Demander un devis</a>' +
            '<a class="abc-btn abc-btn--outline-light" href="tel:+33240897626">📞 ' + TEL + '</a>' +
          '</div>' +
        '</div>');
      footer.parentNode.insertBefore(band, footer);
    }

    // 5. Fiche produit : rappel sur mesure sous le bouton « Ajouter au panier »
    if (page === 'product') {
      var add = document.querySelector('.product-add-to-cart');
      if (add && !document.querySelector('.abc-product-help')) {
        var help = el('p', 'abc-product-help',
          '🎁 Envie d\'un coffret personnalisé ou d\'une commande pour votre entreprise ? ' +
          '<a href="' + BASE + 'nous-contacter">Contactez-nous</a> ou appelez le <a href="tel:+33240897626">' + TEL + '</a>.');
        add.parentNode.insertBefore(help, add.nextSibling);
      }
    }

    // 6. Page de résultats de recherche : proposer les rayons en haut (la recherche renvoie parfois des produits approchants sans rapport)
    if (page === 'search') {
      var products = document.getElementById('products');
      if (products && !document.querySelector('.abc-search-help')) {
        var tips = el('div', 'abc-search-help',
          '<p><strong>Vous ne trouvez pas votre bonheur ?</strong> Parcourez nos rayons, ou <a href="' + BASE + 'nous-contacter">demandez-nous conseil</a> : nous avons encore plus de références en magasin.</p>');
        var list = el('div', 'abc-quick__inner');
        LIENS_RAPIDES.forEach(function (l) {
          var a = el('a', 'abc-chip', esc(l[0])); a.href = BASE + l[1]; list.appendChild(a);
        });
        tips.appendChild(list);
        products.parentNode.insertBefore(tips, products);
      }
    }
  });
})();
